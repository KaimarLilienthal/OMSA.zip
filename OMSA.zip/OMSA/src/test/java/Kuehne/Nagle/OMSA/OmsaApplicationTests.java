package Kuehne.Nagle.OMSA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmsaApplicationTests {

	@Test
	void contextLoads() {
	}

}
